from flask import (Blueprint, render_template, redirect, url_for, request,
                    flash, jsonify, abort, current_app)
from flask_login import login_required, current_user

from app.shop import shop_bp
from app.extensions import db
from app.forms import CheckoutForm
from app.models import Product, Category, Order, OrderItem
from app.utils import get_cart, cart_details, clear_cart, generate_order_code

PRODUCTS_PER_PAGE = 12


@shop_bp.route("/")
def index():
    # Authenticated customers go straight to the store — the landing page is for guests only
    if current_user.is_authenticated and not current_user.is_admin:
        return redirect(url_for("shop.shop"))
    featured = Product.query.filter_by(is_featured=True, is_active=True).limit(8).all()
    categories = Category.query.order_by(Category.name).all()
    return render_template("index.html", featured=featured, categories=categories)


@shop_bp.route("/contact")
def contact():
    return render_template("contact.html")


@shop_bp.route("/shop")
def shop():
    cat_slug = request.args.get("category")
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)

    query = Product.query.filter_by(is_active=True)
    active_category = None
    if cat_slug:
        active_category = Category.query.filter_by(slug=cat_slug).first()
        if active_category:
            query = query.filter_by(category_id=active_category.id)
    if q:
        query = query.filter(Product.name.ilike(f"%{q}%"))

    pagination = query.order_by(Product.name).paginate(page=page, per_page=PRODUCTS_PER_PAGE, error_out=False)
    categories = Category.query.order_by(Category.name).all()
    return render_template("catalog.html", products=pagination.items, pagination=pagination,
                            categories=categories, active_category=active_category, q=q)


@shop_bp.route("/product/<slug>")
def product_detail(slug):
    product = Product.query.filter_by(slug=slug, is_active=True).first_or_404()
    related = (Product.query.filter(Product.category_id == product.category_id,
                                     Product.id != product.id, Product.is_active.is_(True))
               .limit(4).all())
    return render_template("product_detail.html", product=product, related=related)


# ------------------------------------------------------------------- CART --

@shop_bp.route("/cart")
def cart():
    items, subtotal = cart_details()
    fee = current_app.config["DELIVERY_FEE"] if items else 0
    return render_template("cart.html", items=items, subtotal=subtotal,
                            delivery_fee=fee, total=subtotal + fee)


@shop_bp.route("/cart/add/<int:product_id>", methods=["POST"])
def cart_add(product_id):
    product = Product.query.filter_by(id=product_id, is_active=True).first_or_404()
    try:
        qty = max(1, int(request.form.get("qty", 1)))
    except ValueError:
        qty = 1
    if product.stock <= 0:
        flash("That item is currently out of stock.", "error")
        return redirect(request.referrer or url_for("shop.shop"))

    cart = get_cart()
    key = str(product_id)
    new_qty = min(cart.get(key, 0) + qty, product.stock)
    cart[key] = new_qty
    from flask import session
    session.modified = True
    flash(f"{product.name} added to your basket.", "success")
    return redirect(request.referrer or url_for("shop.shop"))


@shop_bp.route("/cart/update/<int:product_id>", methods=["POST"])
def cart_update(product_id):
    from flask import session
    product = Product.query.get_or_404(product_id)
    try:
        qty = int(request.form.get("qty", 1))
    except ValueError:
        qty = 1
    cart = get_cart()
    key = str(product_id)
    if qty <= 0:
        cart.pop(key, None)
    else:
        cart[key] = min(qty, product.stock)
    session.modified = True
    return redirect(url_for("shop.cart"))


@shop_bp.route("/cart/remove/<int:product_id>", methods=["POST"])
def cart_remove(product_id):
    from flask import session
    cart = get_cart()
    cart.pop(str(product_id), None)
    session.modified = True
    return redirect(url_for("shop.cart"))


# --------------------------------------------------------------- CHECKOUT --

@shop_bp.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    items, subtotal = cart_details()
    if not items:
        flash("Your basket is empty.", "error")
        return redirect(url_for("shop.shop"))

    fee = current_app.config["DELIVERY_FEE"]
    total = subtotal + fee

    form = CheckoutForm(full_name=current_user.full_name, phone=current_user.phone,
                         address=current_user.address)

    if form.validate_on_submit():
        # Re-validate stock at the moment of order creation to prevent overselling.
        for item in items:
            if item["qty"] > item["product"].stock:
                flash(f"Only {item['product'].stock} units of {item['product'].name} are available.", "error")
                return redirect(url_for("shop.cart"))

        order = Order(
            order_code=generate_order_code(), user_id=current_user.id,
            full_name=form.full_name.data, phone=form.phone.data,
            delivery_address=form.address.data,
            subtotal=subtotal, delivery_fee=fee, total=total,
        )
        db.session.add(order)
        db.session.flush()

        for item in items:
            db.session.add(OrderItem(
                order_id=order.id, product_id=item["product"].id,
                product_name=item["product"].name,
                unit_price=item["product"].price, qty=item["qty"],
            ))
        db.session.commit()
        return redirect(url_for("shop.pay", order_id=order.id))

    return render_template("checkout.html", items=items, subtotal=subtotal,
                            delivery_fee=fee, total=total, form=form)


@shop_bp.route("/pay/<int:order_id>")
@login_required
def pay(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        abort(403)
    if order.payment_status == "paid":
        return redirect(url_for("shop.order_success", order_id=order.id))
    return render_template("pay.html", order=order)


@shop_bp.route("/payment/verify/<int:order_id>", methods=["POST"])
@login_required
def payment_verify(order_id):
    """Marks an order paid from the Paystack client-side callback reference.

    Production note: this should call Paystack's GET /transaction/verify/{reference}
    server-side (using PAYSTACK_SECRET_KEY) and check status == 'success' and that
    the amount returned matches order.total before trusting payment — the client
    callback alone is not sufficient for a live deployment.
    """
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        return jsonify({"ok": False, "error": "forbidden"}), 403
    if order.payment_status == "paid":
        return jsonify({"ok": True, "redirect": url_for("shop.order_success", order_id=order.id)})

    data = request.get_json(silent=True) or {}
    reference = data.get("reference")
    if not reference:
        return jsonify({"ok": False, "error": "missing reference"}), 400

    order.payment_ref = reference
    order.payment_status = "paid"
    order.order_status = "Order Received"

    for item in order.items:
        product = Product.query.get(item.product_id)
        if product:
            product.stock = max(0, product.stock - item.qty)

    db.session.commit()
    clear_cart()
    return jsonify({"ok": True, "redirect": url_for("shop.order_success", order_id=order.id)})


@shop_bp.route("/order/success/<int:order_id>")
@login_required
def order_success(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id and not current_user.is_admin:
        abort(403)
    return render_template("order_success.html", order=order)


@shop_bp.route("/account/orders")
@login_required
def my_orders():
    from app.models import ORDER_STAGES
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template("my_orders.html", orders=orders, stages=ORDER_STAGES)
