import os
import logging
from logging.handlers import RotatingFileHandler

from flask import Flask, render_template

from app.config import config_by_name
from app.extensions import db, migrate, login_manager, csrf, limiter


def create_app(config_name=None):
    config_name = config_name or os.environ.get("FLASK_ENV", "development")
    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])

    if hasattr(config_by_name[config_name], "validate"):
        config_by_name[config_name].validate()

    # --- extensions ---
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    from app.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # --- blueprints ---
    from app.auth.routes import auth_bp
    from app.shop.routes import shop_bp
    from app.admin.routes import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(shop_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")

    # --- context processors ---
    from app.models import Category, SiteSetting
    from app.utils import get_cart

    @app.context_processor
    def inject_globals():
        cart = get_cart()
        cart_count = sum(cart.values()) if cart else 0
        categories = Category.query.order_by(Category.name).all()
        # make all site settings available as a dict in every template
        settings = {s.key: s.value for s in SiteSetting.query.all()}
        return dict(
            cart_count=cart_count,
            nav_categories=categories,
            site=settings,
            paystack_public_key=settings.get(
                "paystack_public_key",
                app.config.get("PAYSTACK_PUBLIC_KEY", "")
            ),
        )

    # --- security headers ---
    @app.after_request
    def set_secure_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return response

    # --- error handlers ---
    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(429)
    def too_many_requests(e):
        return render_template("errors/429.html"), 429

    @app.errorhandler(500)
    def server_error(e):
        app.logger.exception("Unhandled server error")
        return render_template("errors/500.html"), 500

    # --- logging ---
    if not app.debug and not app.testing:
        os.makedirs(os.path.join(app.root_path, "..", "logs"), exist_ok=True)
        handler = RotatingFileHandler(
            os.path.join(app.root_path, "..", "logs", "agriinvest.log"),
            maxBytes=1_000_000, backupCount=3,
        )
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s: %(message)s"
        ))
        handler.setLevel(logging.INFO)
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)

    # --- CLI: seed database ---
    @app.cli.command("seed-db")
    def seed_db_command():
        """Populate the database with starter categories/products/accounts."""
        from app.seed import seed_data
        seed_data()
        print("Database seeded.")

    return app
