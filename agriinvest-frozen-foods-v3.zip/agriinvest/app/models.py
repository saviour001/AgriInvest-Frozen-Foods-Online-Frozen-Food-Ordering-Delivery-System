from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import CheckConstraint

from app.extensions import db


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(20))
    address = db.Column(db.String(255))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="customer")  # customer | admin
    is_active_account = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login_at = db.Column(db.DateTime)

    orders = db.relationship("Order", backref="customer", lazy=True)

    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    @property
    def is_admin(self):
        return self.role == "admin"

    # Flask-Login uses .is_active; map it to our account-disable flag
    @property
    def is_active(self):
        return self.is_active_account

    def __repr__(self):
        return f"<User {self.email}>"


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    slug = db.Column(db.String(80), unique=True, nullable=False, index=True)
    icon = db.Column(db.String(10), default="\U0001F9CA")
    storage_temp = db.Column(db.String(20), default="-18\u00b0C")
    default_image_url = db.Column(db.String(500))

    products = db.relationship("Product", backref="category", lazy=True)


class Product(db.Model):
    __tablename__ = "products"
    __table_args__ = (
        CheckConstraint("price >= 0", name="ck_product_price_nonneg"),
        CheckConstraint("stock >= 0", name="ck_product_stock_nonneg"),
    )

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    slug = db.Column(db.String(160), unique=True, nullable=False, index=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    price = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(30), default="pack")
    stock = db.Column(db.Integer, default=0, nullable=False)
    description = db.Column(db.Text)
    storage_temp = db.Column(db.String(20), default="-18\u00b0C")
    shelf_life_days = db.Column(db.Integer, default=180)
    is_featured = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False, index=True)
    accent = db.Column(db.String(20), default="a1")
    icon = db.Column(db.String(10), default="\U0001F9CA")
    image_filename = db.Column(db.String(255))  # set when admin uploads a photo
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    creator = db.relationship("User")

    def in_stock(self):
        return self.stock > 0


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    order_code = db.Column(db.String(24), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    full_name = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    delivery_address = db.Column(db.String(255))
    subtotal = db.Column(db.Float, default=0)
    delivery_fee = db.Column(db.Float, default=0)
    total = db.Column(db.Float, default=0)
    payment_ref = db.Column(db.String(80))
    payment_status = db.Column(db.String(20), default="pending", index=True)  # pending/paid/failed
    order_status = db.Column(db.String(30), default="Order Received")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    items = db.relationship("OrderItem", backref="order", lazy=True, cascade="all, delete-orphan")


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"))
    product_name = db.Column(db.String(120))
    unit_price = db.Column(db.Float)
    qty = db.Column(db.Integer)

    product = db.relationship("Product")

    @property
    def line_total(self):
        return self.unit_price * self.qty


ORDER_STAGES = ["Order Received", "Packed in Cold Storage", "Out for Delivery", "Delivered"]


class SiteSetting(db.Model):
    """Key-value store for all admin-configurable site settings.
    Admin can change anything here without touching code."""
    __tablename__ = "site_settings"

    id  = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(80), unique=True, nullable=False, index=True)
    value = db.Column(db.Text)
    label = db.Column(db.String(120))        # human-readable label shown in admin UI
    group = db.Column(db.String(40))         # 'store' | 'payment' | 'delivery'
    input_type = db.Column(db.String(20), default="text")  # text | textarea | number | password

    @staticmethod
    def get(key, default=""):
        row = SiteSetting.query.filter_by(key=key).first()
        return row.value if row and row.value is not None else default

    @staticmethod
    def set(key, value):
        row = SiteSetting.query.filter_by(key=key).first()
        if row:
            row.value = value
        else:
            db.session.add(SiteSetting(key=key, value=value))
        db.session.commit()

