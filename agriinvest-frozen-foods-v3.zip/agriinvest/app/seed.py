from app.extensions import db
from app.models import Category, Product, User, SiteSetting
from app.utils import slugify


DEFAULT_SETTINGS = [
    # group: store
    ("store_name",        "AgriInvest Frozen Foods",          "Store name",             "store", "text"),
    ("store_tagline",     "Farm-fresh. Flash-frozen. Delivered cold.", "Tagline",        "store", "text"),
    ("store_email",       "admin@agriinvest.ng",              "Contact email",           "store", "text"),
    ("store_phone",       "+234 800 000 0000",                "Contact phone",           "store", "text"),
    ("store_address",     "Lafia–Akwanga Road, Nasarawa State, Nigeria", "Office address","store", "textarea"),
    ("store_hours",       "Monday – Saturday, 8:00 am – 7:00 pm", "Opening hours",      "store", "text"),
    ("store_whatsapp",    "",                                  "WhatsApp number",        "store", "text"),
    # group: delivery
    ("delivery_fee",      "1500",                             "Delivery fee (₦)",        "delivery", "number"),
    ("delivery_areas",    "Lafia, Nasarawa & FCT",            "Delivery areas",          "delivery", "text"),
    # group: payment
    ("paystack_public_key", "pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                                                              "Paystack public key",     "payment", "text"),
    ("paystack_secret_key", "",                               "Paystack secret key",     "payment", "password"),
    ("payment_channels",  "card,bank_transfer,bank,ussd",     "Enabled payment channels (comma-separated)", "payment", "text"),
]


def seed_data():
    if Category.query.count() > 0:
        return

    # --- default site settings ---
    for key, value, label, group, input_type in DEFAULT_SETTINGS:
        if not SiteSetting.query.filter_by(key=key).first():
            db.session.add(SiteSetting(key=key, value=value, label=label,
                                        group=group, input_type=input_type))
    db.session.commit()

    cats = [
        Category(name="Poultry", slug="poultry", icon="\U0001F414", storage_temp="-18\u00b0C",
                  default_image_url="img/cat-poultry.jpg"),
        Category(name="Red Meat", slug="meat", icon="\U0001F356", storage_temp="-18\u00b0C",
                  default_image_url="img/cat-meat.jpg"),
        Category(name="Seafood", slug="seafood", icon="\U0001F41F", storage_temp="-20\u00b0C",
                  default_image_url="img/cat-seafood.jpg"),
        Category(name="Frozen Vegetables", slug="vegetables", icon="\U0001F966", storage_temp="-12\u00b0C",
                  default_image_url="img/cat-vegetables.jpg"),
        Category(name="Ready Meals", slug="ready-meals", icon="\U0001F372", storage_temp="-18\u00b0C",
                  default_image_url="img/cat-ready-meals.jpg"),
    ]
    db.session.add_all(cats)
    db.session.commit()
    by_slug = {c.slug: c for c in cats}

    admin = User(full_name="AgriInvest Admin", email="admin@agriinvest.ng",
                 phone="08000000000", address="AgriInvest Ltd, Nasarawa", role="admin")
    admin.set_password("Admin12345")
    demo = User(full_name="Demo Customer", email="customer@example.com",
                phone="08011112222", address="12 Garki Street, Lafia", role="customer")
    demo.set_password("Customer123")
    db.session.add_all([admin, demo])
    db.session.commit()

    products = [
        ("Whole Chicken (Dressed)", "poultry", 6500, "1.5kg bird", 45, True, "a1"),
        ("Chicken Breast Fillet", "poultry", 4200, "1kg pack", 60, True, "a2"),
        ("Turkey Drumsticks", "poultry", 5800, "1kg pack", 30, False, "a1"),
        ("Chicken Wings", "poultry", 3500, "1kg pack", 80, False, "a2"),
        ("Beef Cubes", "meat", 7200, "1kg pack", 40, True, "a3"),
        ("Goat Meat (Assorted Cuts)", "meat", 8500, "1kg pack", 25, False, "a3"),
        ("Beef Suya Cuts", "meat", 6800, "1kg pack", 35, True, "a4"),
        ("Premium Beef Steak", "meat", 9800, "800g pack", 15, False, "a3"),
        ("Atlantic Mackerel (Titus Fish)", "seafood", 4800, "1kg pack", 50, True, "a5"),
        ("Jumbo Prawns", "seafood", 9500, "500g pack", 20, True, "a6"),
        ("Catfish Fillet", "seafood", 5200, "1kg pack", 38, False, "a5"),
        ("Croaker Fish (Whole)", "seafood", 6200, "1.2kg pack", 28, False, "a6"),
        ("Mixed Vegetable Medley", "vegetables", 1800, "500g pack", 100, False, "a7"),
        ("Sweet Corn Kernels", "vegetables", 1500, "500g pack", 90, False, "a7"),
        ("Green Peas", "vegetables", 1600, "500g pack", 85, False, "a7"),
        ("Diced Bell Pepper Mix (Tatashe & Onion)", "vegetables", 2000, "500g pack", 70, True, "a7"),
        ("Jollof Rice & Chicken Tray", "ready-meals", 3200, "ready tray", 40, True, "a8"),
        ("Beef Suya Stir-fry Pack", "ready-meals", 3500, "ready tray", 32, False, "a8"),
        ("Fried Rice & Turkey Tray", "ready-meals", 3400, "ready tray", 36, False, "a8"),
        ("Egusi Soup with Beef Pack", "ready-meals", 3000, "ready tray", 25, True, "a8"),
    ]
    for name, cat_slug, price, unit, stock, featured, accent in products:
        cat = by_slug[cat_slug]
        db.session.add(Product(
            name=name, slug=slugify(name), category_id=cat.id, price=price, unit=unit,
            stock=stock, is_featured=featured, accent=accent, icon=cat.icon,
            storage_temp=cat.storage_temp, shelf_life_days=180, created_by_id=admin.id,
            description=f"Premium {name.lower()}, blast-frozen at source and held at {cat.storage_temp} "
                         f"throughout the AgriInvest cold chain to lock in freshness, nutrients and flavour."
        ))
    db.session.commit()
