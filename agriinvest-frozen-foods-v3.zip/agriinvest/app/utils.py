import os
import uuid
from datetime import datetime

from flask import session, current_app
from werkzeug.utils import secure_filename


def save_product_image(file_storage):
    """Securely persist an uploaded product image and return its stored filename.
    Returns None if no file was supplied."""
    if not file_storage or not file_storage.filename:
        return None

    filename = secure_filename(file_storage.filename)
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in current_app.config["ALLOWED_IMAGE_EXTENSIONS"]:
        return None

    unique_name = f"{uuid.uuid4().hex}.{ext}"
    upload_folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_folder, exist_ok=True)
    file_storage.save(os.path.join(upload_folder, unique_name))
    return unique_name


def delete_product_image(filename):
    if not filename:
        return
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
    if os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            current_app.logger.warning("Could not delete image file: %s", path)


def generate_order_code():
    return "AIV" + datetime.utcnow().strftime("%y%m%d%H%M%S") + uuid.uuid4().hex[:4].upper()


def get_cart():
    return session.setdefault("cart", {})


def clear_cart():
    session["cart"] = {}
    session.modified = True


def cart_details():
    from app.models import Product  # local import avoids circular import at module load

    cart = get_cart()
    items = []
    subtotal = 0.0
    dirty = False
    for pid, qty in list(cart.items()):
        product = Product.query.get(int(pid))
        if not product or not product.is_active:
            cart.pop(pid, None)
            dirty = True
            continue
        qty = min(qty, product.stock) if product.stock else qty
        line_total = product.price * qty
        subtotal += line_total
        items.append({"product": product, "qty": qty, "line_total": line_total})
    if dirty:
        session.modified = True
    return items, subtotal


def slugify(value):
    return "-".join(
        "".join(c for c in value.lower() if c.isalnum() or c.isspace()).split()
    )
