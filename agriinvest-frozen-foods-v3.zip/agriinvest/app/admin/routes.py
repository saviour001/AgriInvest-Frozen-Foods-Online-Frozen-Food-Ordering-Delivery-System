from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_wtf import FlaskForm

from app.admin import admin_bp
from app.admin.decorators import admin_required
from app.extensions import db
from app.forms import ProductForm
from app.models import Product, Category, Order, ORDER_STAGES
from app.utils import save_product_image, delete_product_image, slugify

PRODUCTS_PER_PAGE = 15
ORDERS_PER_PAGE = 15


@admin_bp.route("/")
@admin_required
def dashboard():
    total_orders = Order.query.count()
    revenue = db.session.query(db.func.coalesce(db.func.sum(Order.total), 0)) \
        .filter(Order.payment_status == "paid").scalar()
    total_products = Product.query.filter_by(is_active=True).count()
    low_stock = Product.query.filter(Product.stock <= 10, Product.is_active.is_(True)).all()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(6).all()
    return render_template("admin/dashboard.html", total_orders=total_orders,
                            revenue=revenue, total_products=total_products,
                            low_stock=low_stock, recent_orders=recent_orders)


@admin_bp.route("/products")
@admin_required
def products():
    page = request.args.get("page", 1, type=int)
    pagination = Product.query.filter_by(is_active=True) \
        .order_by(Product.id.desc()).paginate(page=page, per_page=PRODUCTS_PER_PAGE, error_out=False)
    categories = Category.query.order_by(Category.name).all()

    form = ProductForm()
    form.category_id.choices = [(c.id, c.name) for c in categories]

    return render_template("admin/products.html", products=pagination.items,
                            pagination=pagination, categories=categories, form=form)


@admin_bp.route("/products/add", methods=["POST"])
@admin_required
def add_product():
    categories = Category.query.order_by(Category.name).all()
    form = ProductForm()
    form.category_id.choices = [(c.id, c.name) for c in categories]

    if form.validate_on_submit():
        category = Category.query.get(form.category_id.data)
        base_slug = slugify(form.name.data)
        slug = base_slug
        suffix = 1
        while Product.query.filter_by(slug=slug).first():
            suffix += 1
            slug = f"{base_slug}-{suffix}"

        image_filename = save_product_image(form.image.data)

        product = Product(
            name=form.name.data.strip(), slug=slug, category_id=category.id,
            price=form.price.data, unit=form.unit.data.strip(), stock=form.stock.data,
            description=(form.description.data or "").strip(),
            storage_temp=category.storage_temp,
            shelf_life_days=form.shelf_life_days.data or 180,
            is_featured=form.is_featured.data,
            icon=category.icon, image_filename=image_filename,
        )
        db.session.add(product)
        db.session.commit()
        flash(f"{product.name} added to the catalog.", "success")
    else:
        for field, errors in form.errors.items():
            for err in errors:
                flash(f"{field}: {err}", "error")

    return redirect(url_for("admin.products"))


@admin_bp.route("/products/<int:product_id>/delete", methods=["POST"])
@admin_required
def delete_product(product_id):
    """Soft-delete: keeps historical order records intact while removing the
    item from the storefront, and deletes its uploaded image from disk."""
    product = Product.query.get_or_404(product_id)
    product.is_active = False
    db.session.commit()
    delete_product_image(product.image_filename)
    flash(f"{product.name} removed from the catalog.", "success")
    return redirect(url_for("admin.products"))


@admin_bp.route("/orders")
@admin_required
def orders():
    page = request.args.get("page", 1, type=int)
    pagination = Order.query.order_by(Order.created_at.desc()) \
        .paginate(page=page, per_page=ORDERS_PER_PAGE, error_out=False)
    return render_template("admin/orders.html", orders=pagination.items,
                            pagination=pagination, stages=ORDER_STAGES)


@admin_bp.route("/orders/<int:order_id>/status", methods=["POST"])
@admin_required
def update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get("status")
    if new_status in ORDER_STAGES:
        order.order_status = new_status
        db.session.commit()
        flash("Order status updated.", "success")
    return redirect(url_for("admin.orders"))


@admin_bp.route("/users")
@admin_required
def users():
    from app.models import User
    all_users = User.query.filter_by(role="customer").order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=all_users)


@admin_bp.route("/users/<int:user_id>/reset-password", methods=["GET", "POST"])
@admin_required
def reset_user_password(user_id):
    from app.models import User
    from app.forms import AdminResetPasswordForm
    user = User.query.get_or_404(user_id)
    if user.is_admin:
        flash("Cannot reset another admin's password from this panel.", "error")
        return redirect(url_for("admin.users"))
    form = AdminResetPasswordForm()
    if form.validate_on_submit():
        user.set_password(form.new_password.data)
        db.session.commit()
        flash(f"Password for {user.full_name} has been reset.", "success")
        return redirect(url_for("admin.users"))
    return render_template("admin/reset_user_password.html", form=form, user=user)


@admin_bp.route("/users/<int:user_id>/toggle-status", methods=["POST"])
@admin_required
def toggle_user_status(user_id):
    from app.models import User
    user = User.query.get_or_404(user_id)
    if user.is_admin:
        flash("Cannot deactivate an admin account.", "error")
        return redirect(url_for("admin.users"))
    user.is_active_account = not user.is_active_account
    db.session.commit()
    status = "activated" if user.is_active_account else "deactivated"
    flash(f"Account for {user.full_name} has been {status}.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    from app.models import SiteSetting
    if request.method == "POST":
        for key, value in request.form.items():
            if key == "csrf_token":
                continue
            row = SiteSetting.query.filter_by(key=key).first()
            if row:
                row.value = value.strip()
        db.session.commit()
        flash("Settings saved successfully.", "success")
        return redirect(url_for("admin.settings"))
    all_settings = SiteSetting.query.order_by(SiteSetting.group, SiteSetting.id).all()
    groups = {}
    for s in all_settings:
        groups.setdefault(s.group, []).append(s)
    return render_template("admin/settings.html", groups=groups)


@admin_bp.route("/profile", methods=["GET", "POST"])
@admin_required
def profile():
    from flask_login import current_user
    if request.method == "POST":
        action = request.form.get("action")
        if action == "update_info":
            current_user.full_name = request.form.get("full_name", "").strip()
            current_user.phone     = request.form.get("phone", "").strip()
            current_user.address   = request.form.get("address", "").strip()
            new_email = request.form.get("email", "").strip().lower()
            from app.models import User
            existing = User.query.filter(User.email == new_email,
                                          User.id != current_user.id).first()
            if existing:
                flash("That email is already used by another account.", "error")
            else:
                current_user.email = new_email
                db.session.commit()
                flash("Profile updated.", "success")
        elif action == "change_password":
            current_pw   = request.form.get("current_password", "")
            new_pw       = request.form.get("new_password", "")
            confirm_pw   = request.form.get("confirm_password", "")
            if not current_user.check_password(current_pw):
                flash("Current password is incorrect.", "error")
            elif len(new_pw) < 8:
                flash("Password must be at least 8 characters.", "error")
            elif new_pw != confirm_pw:
                flash("Passwords do not match.", "error")
            else:
                current_user.set_password(new_pw)
                db.session.commit()
                flash("Password changed successfully.", "success")
    return render_template("admin/profile.html")
