from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import (StringField, PasswordField, TextAreaField, SelectField,
                      FloatField, IntegerField, BooleanField, SubmitField)
from wtforms.validators import (DataRequired, Email, Length, EqualTo,
                                 NumberRange, Optional, Regexp)


class RegisterForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(2, 120)])
    email = StringField("Email address", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Phone number", validators=[Optional(), Length(max=20)])
    address = TextAreaField("Delivery address", validators=[Optional(), Length(max=255)])
    password = PasswordField(
        "Password",
        validators=[
            DataRequired(),
            Length(min=8, message="Password must be at least 8 characters."),
            Regexp(r"^(?=.*[A-Za-z])(?=.*\d).+$",
                   message="Password must contain at least one letter and one number."),
        ],
    )
    confirm_password = PasswordField(
        "Confirm password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match.")],
    )
    submit = SubmitField("Create account")


class LoginForm(FlaskForm):
    email = StringField("Email address", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    remember = BooleanField("Keep me signed in")
    submit = SubmitField("Sign in")


class CheckoutForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(2, 120)])
    phone = StringField("Phone number", validators=[DataRequired(), Length(7, 20)])
    address = TextAreaField("Delivery address", validators=[DataRequired(), Length(5, 255)])
    submit = SubmitField("Continue to payment")


class ChangePasswordForm(FlaskForm):
    current_password = PasswordField("Current password", validators=[DataRequired()])
    new_password = PasswordField(
        "New password",
        validators=[
            DataRequired(),
            Length(min=8, message="Password must be at least 8 characters."),
            Regexp(r"^(?=.*[A-Za-z])(?=.*\d).+$",
                   message="Password must contain at least one letter and one number."),
        ],
    )
    confirm_new_password = PasswordField(
        "Confirm new password",
        validators=[DataRequired(), EqualTo("new_password", message="Passwords must match.")],
    )
    submit = SubmitField("Update password")


class AdminResetPasswordForm(FlaskForm):
    new_password = PasswordField(
        "New password for user",
        validators=[
            DataRequired(),
            Length(min=8, message="Password must be at least 8 characters."),
            Regexp(r"^(?=.*[A-Za-z])(?=.*\d).+$",
                   message="Must contain at least one letter and one number."),
        ],
    )
    confirm_password = PasswordField(
        "Confirm new password",
        validators=[DataRequired(), EqualTo("new_password", message="Passwords must match.")],
    )
    submit = SubmitField("Reset password")


class ProductForm(FlaskForm):
    name = StringField("Product name", validators=[DataRequired(), Length(2, 120)])
    category_id = SelectField("Category", coerce=int, validators=[DataRequired()])
    price = FloatField("Price (\u20a6)", validators=[DataRequired(), NumberRange(min=1)])
    unit = StringField("Unit / pack size", validators=[DataRequired(), Length(1, 30)])
    stock = IntegerField("Stock quantity", validators=[DataRequired(), NumberRange(min=0)])
    shelf_life_days = IntegerField("Shelf life (days frozen)",
                                    validators=[Optional(), NumberRange(min=1, max=1000)])
    description = TextAreaField("Description", validators=[Optional(), Length(max=2000)])
    is_featured = BooleanField("Mark as featured / top pick")
    image = FileField("Product photo", validators=[
        Optional(),
        FileAllowed(["png", "jpg", "jpeg", "webp"], "Images only (png, jpg, jpeg, webp)."),
    ])
    submit = SubmitField("Save product")
    name = StringField("Product name", validators=[DataRequired(), Length(2, 120)])
    category_id = SelectField("Category", coerce=int, validators=[DataRequired()])
    price = FloatField("Price (\u20a6)", validators=[DataRequired(), NumberRange(min=1)])
    unit = StringField("Unit / pack size", validators=[DataRequired(), Length(1, 30)])
    stock = IntegerField("Stock quantity", validators=[DataRequired(), NumberRange(min=0)])
    shelf_life_days = IntegerField("Shelf life (days frozen)",
                                    validators=[Optional(), NumberRange(min=1, max=1000)])
    description = TextAreaField("Description", validators=[Optional(), Length(max=2000)])
    is_featured = BooleanField("Mark as featured / top pick")
    image = FileField("Product photo", validators=[
        Optional(),
        FileAllowed(["png", "jpg", "jpeg", "webp"], "Images only (png, jpg, jpeg, webp)."),
    ])
    submit = SubmitField("Save product")
