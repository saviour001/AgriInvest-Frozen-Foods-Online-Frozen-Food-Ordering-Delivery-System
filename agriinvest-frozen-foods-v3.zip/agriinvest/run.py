import os
from app import create_app
from app.extensions import db
from app.seed import seed_data

app = create_app(os.environ.get("FLASK_ENV", "development"))

with app.app_context():
    db.create_all()
    seed_data()

if __name__ == "__main__":
    app.run(debug=app.config.get("DEBUG", False))
